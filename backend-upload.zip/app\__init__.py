"""YouyuCursor 后端管理系统"""

__version__ = "1.0.0"


