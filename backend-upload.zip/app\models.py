#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""数据库模型定义"""

from sqlalchemy import Column, Integer, String, DateTime, Boolean, Float, Text
from sqlalchemy.sql import func
from datetime import datetime, timezone, timedelta
from app.database import Base

# 北京时区（UTC+8）
BEIJING_TZ = timezone(timedelta(hours=8))


def beijing_now():
    """返回北京时间"""
    return datetime.now(BEIJING_TZ)


class Admin(Base):
    """管理员表"""
    __tablename__ = "admins"
    
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(50), unique=True, index=True, nullable=False)
    password_hash = Column(String(200), nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class Account(Base):
    """账号表"""
    __tablename__ = "accounts"
    
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(200), unique=True, index=True, nullable=False)
    access_token = Column(Text, nullable=False)
    session_token = Column(Text, nullable=True)
    
    # 账号状态
    membership_type = Column(String(50), nullable=True)  # pro_trial, pro, free_trial, free
    usage_percent = Column(Float, default=0.0)  # 使用额度百分比
    trial_days_left = Column(Integer, default=0)  # 试用剩余天数
    
    # 状态: valid(有效), in_use(使用中), expired(已失效)
    status = Column(String(20), default="valid", index=True)
    
    # 关联信息
    used_by_key = Column(String(100), nullable=True)  # 使用的密钥ID
    
    # 时间戳（使用北京时区）
    created_at = Column(DateTime(timezone=True), default=beijing_now, nullable=False)
    updated_at = Column(DateTime(timezone=True), onupdate=beijing_now)
    moved_to_in_use_at = Column(DateTime(timezone=True), nullable=True)
    moved_to_expired_at = Column(DateTime(timezone=True), nullable=True)


class APIKey(Base):
    """
    API密钥表
    
    按需获取模式：
    - quota: 总配额数量（1或5）
    - used_count: 已使用次数（0-quota）
    - remaining_quota: 剩余次数（通过 quota - used_count 计算）
    - used: 是否已完全使用（used_count >= quota）
    """
    __tablename__ = "api_keys"
    
    id = Column(Integer, primary_key=True, index=True)
    key = Column(String(200), unique=True, index=True, nullable=False)
    quota = Column(Integer, nullable=False)  # 总配额数量（1或5）
    used_count = Column(Integer, default=0, nullable=False)  # 已使用次数
    used = Column(Boolean, default=False)  # 是否已完全使用（兼容性字段）
    
    # 时间戳（使用北京时区）
    created_at = Column(DateTime(timezone=True), default=beijing_now, nullable=False)
    used_at = Column(DateTime(timezone=True), nullable=True)  # 完全使用完的时间
    first_used_at = Column(DateTime(timezone=True), nullable=True)  # 首次使用时间
    
    @property
    def remaining_quota(self):
        """计算剩余配额"""
        return max(0, self.quota - self.used_count)


class SystemConfig(Base):
    """系统配置表"""
    __tablename__ = "system_configs"
    
    id = Column(Integer, primary_key=True, index=True)
    key = Column(String(100), unique=True, index=True, nullable=False)  # 配置键
    value = Column(Text, nullable=False)  # 配置值（JSON字符串）
    description = Column(String(200), nullable=True)  # 配置说明
    updated_at = Column(DateTime(timezone=True), default=beijing_now, onupdate=beijing_now)


class RequestLog(Base):
    """
    请求日志表（防重放攻击）
    V3.2.7 新增
    
    记录所有的账号获取请求，防止重放攻击
    """
    __tablename__ = "request_logs"
    
    id = Column(Integer, primary_key=True, index=True)
    request_id = Column(String(200), unique=True, index=True, nullable=False)  # 唯一请求ID
    key = Column(String(200), index=True, nullable=False)  # API密钥
    timestamp = Column(DateTime(timezone=True), nullable=False)  # 请求时间
    created_at = Column(DateTime(timezone=True), default=beijing_now, nullable=False)  # 记录创建时间
    
    def __repr__(self):
        return f"<RequestLog(id={self.id}, request_id='{self.request_id[:20]}...', key='{self.key[:10]}...')>"


