#!/usr/bin/env python3
"""
YouyuCursor 管理员初始化脚本
用于创建或重置管理员账号
"""

import sys
import getpass
from pathlib import Path

# 添加项目根目录到路径
sys.path.insert(0, str(Path(__file__).parent))

from sqlalchemy.orm import Session
from app.database import SessionLocal, engine, Base
from app.models import Admin
from app.auth import get_password_hash


def create_admin(username: str, password: str, db: Session):
    """创建管理员账号"""
    # 检查是否已存在
    existing = db.query(Admin).filter(Admin.username == username).first()
    if existing:
        print(f"[WARNING] Admin '{username}' already exists")
        choice = input("Reset password? (y/n): ").strip().lower()
        if choice != 'y':
            print("[INFO] Operation cancelled")
            return False
        
        # 重置密码
        existing.password_hash = get_password_hash(password)
        db.commit()
        print(f"[OK] Admin '{username}' password reset")
        return True
    
    # 创建新管理员
    admin = Admin(
        username=username,
        password_hash=get_password_hash(password)
    )
    db.add(admin)
    db.commit()
    print(f"[OK] Admin '{username}' created successfully")
    return True


def main():
    """主函数"""
    print("=" * 50)
    print("  YouyuCursor Admin Initialization")
    print("=" * 50)
    print()
    
    # 创建数据库表
    print("[INFO] Initializing database...")
    Base.metadata.create_all(bind=engine)
    print("[OK] Database initialized")
    print()
    
    # 获取管理员信息
    if len(sys.argv) >= 3:
        # 从命令行参数获取
        username = sys.argv[1]
        password = sys.argv[2]
        print(f"[INFO] Using command line arguments")
        print(f"   Username: {username}")
        print(f"   Password: {'*' * len(password)}")
    else:
        # 交互式输入
        print("Enter admin information:")
        username = input("Username: ").strip()
        if not username:
            print("[ERROR] Username cannot be empty")
            return 1
        
        password = getpass.getpass("Password: ").strip()
        if not password:
            print("[ERROR] Password cannot be empty")
            return 1
        
        password_confirm = getpass.getpass("Confirm password: ").strip()
        if password != password_confirm:
            print("[ERROR] Passwords do not match")
            return 1
    
    print()
    
    # 创建管理员
    db = SessionLocal()
    try:
        success = create_admin(username, password, db)
        if success:
            print()
            print("=" * 50)
            print("[OK] Complete!")
            print("=" * 50)
            print()
            print("You can now login with:")
            print(f"  Username: {username}")
            print(f"  Password: {'*' * len(password)}")
            print()
            print("Access: http://localhost:8000")
            print("=" * 50)
            return 0
        else:
            return 1
    except Exception as e:
        print(f"[ERROR] {e}")
        return 1
    finally:
        db.close()


if __name__ == "__main__":
    sys.exit(main())


