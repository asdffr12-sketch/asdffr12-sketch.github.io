#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""数据库 CRUD 操作 - V2按需获取版本"""

from datetime import datetime
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import Optional, Tuple
import logging

from app.models import Account, APIKey

logger = logging.getLogger(__name__)


def validate_key_only(db: Session, key: str) -> Optional[APIKey]:
    """
    验证密钥（仅验证，不分配账号）
    
    Returns:
        APIKey对象 如果密钥有效且有剩余次数
        None 如果密钥无效或已用完
    """
    api_key = db.query(APIKey).filter(APIKey.key == key).first()
    
    if not api_key:
        logger.warning(f"密钥不存在: {key}")
        return None
    
    # 检查剩余次数
    if api_key.used_count >= api_key.quota:
        logger.warning(f"密钥已用完: {key}, 使用次数: {api_key.used_count}/{api_key.quota}")
        return None
    
    logger.info(f"密钥验证成功: {key}, 剩余次数: {api_key.remaining_quota}/{api_key.quota}")
    return api_key


def fetch_one_account_with_key(db: Session, key: str) -> Optional[Tuple[Account, int]]:
    """
    使用密钥获取一个账号（按需获取模式）
    
    流程：
    1. 验证密钥有效性和剩余次数
    2. 从valid状态获取一个最早的账号
    3. 更新密钥使用次数
    4. 更新账号状态为in_use
    5. 返回账号和剩余次数
    
    Returns:
        Tuple[Account, int]: (账号对象, 剩余次数)
        None: 如果失败
    """
    try:
        # 1. 获取并验证密钥（加行锁防止并发）
        api_key = db.query(APIKey).filter(APIKey.key == key).with_for_update().first()
        
        if not api_key:
            logger.warning(f"密钥不存在: {key}")
            return None
        
        # 检查剩余次数
        if api_key.used_count >= api_key.quota:
            logger.warning(f"密钥已用完: {key}, 使用: {api_key.used_count}/{api_key.quota}")
            return None
        
        # 2. 获取一个有效账号（加行锁防止并发）
        account = db.query(Account)\
            .filter(Account.status == "valid")\
            .order_by(Account.created_at.asc())\
            .with_for_update()\
            .first()
        
        if not account:
            logger.warning(f"没有可用账号")
            return None
        
        # 3. 更新密钥使用计数
        api_key.used_count += 1
        
        # 首次使用记录时间
        if api_key.used_count == 1:
            api_key.first_used_at = datetime.now()
        
        # 用完时标记
        if api_key.used_count >= api_key.quota:
            api_key.used = True
            api_key.used_at = datetime.now()
        
        remaining = api_key.remaining_quota
        
        # 4. 更新账号状态
        account.status = "in_use"
        account.used_by_key = api_key.key
        account.moved_to_in_use_at = datetime.now()
        
        # 5. 提交事务
        db.commit()
        db.refresh(account)
        db.refresh(api_key)
        
        logger.info(f"✓ 账号分配成功: {account.email}")
        logger.info(f"  密钥: {key}")
        logger.info(f"  已使用: {api_key.used_count}/{api_key.quota}")
        logger.info(f"  剩余: {remaining}")
        
        return (account, remaining)
        
    except Exception as e:
        logger.error(f"获取账号失败: {e}", exc_info=True)
        db.rollback()
        return None


def get_key_status(db: Session, key: str) -> Optional[dict]:
    """
    获取密钥状态信息
    
    Returns:
        dict: {
            "key": str,
            "quota": int,
            "used_count": int,
            "remaining_quota": int,
            "is_valid": bool
        }
    """
    api_key = db.query(APIKey).filter(APIKey.key == key).first()
    
    if not api_key:
        return None
    
    return {
        "key": api_key.key,
        "quota": api_key.quota,
        "used_count": api_key.used_count,
        "remaining_quota": api_key.remaining_quota,
        "is_valid": api_key.used_count < api_key.quota
    }


def get_available_accounts_count(db: Session) -> int:
    """获取可用账号数量"""
    return db.query(func.count(Account.id))\
        .filter(Account.status == "valid")\
        .scalar()



