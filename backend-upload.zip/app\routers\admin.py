#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""管理员认证路由"""

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from datetime import timedelta

from app.database import get_db
from app.schemas import AdminLogin, Token
from app.auth import authenticate_admin, create_access_token, ACCESS_TOKEN_EXPIRE_MINUTES

router = APIRouter(prefix="/api/admin", tags=["管理员"])


@router.post("/login", response_model=Token)
def login(admin_data: AdminLogin, db: Session = Depends(get_db)):
    """管理员登录"""
    admin = authenticate_admin(db, admin_data.username, admin_data.password)
    
    if not admin:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="用户名或密码错误",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": admin.username},
        expires_delta=access_token_expires
    )
    
    return {"access_token": access_token, "token_type": "bearer"}


