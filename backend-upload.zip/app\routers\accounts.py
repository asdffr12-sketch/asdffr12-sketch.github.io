#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""账号管理路由"""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from datetime import datetime

from app.database import get_db
from app.schemas import (
    AccountImport, AccountResponse, AccountUpdate, Stats
)
from app.models import Admin, Account, beijing_now
from app.auth import get_current_admin
from app import crud

router = APIRouter(prefix="/api/accounts", tags=["账号管理"])


def check_and_update_expired_accounts(db: Session):
    """检查并自动更新已失效的账号"""
    # 获取所有非expired状态的账号
    accounts = db.query(Account).filter(Account.status.in_(["valid", "in_use"])).all()
    
    updated_count = 0
    for account in accounts:
        should_expire = False
        reasons = []
        
        # 条件1：使用额度达到100%
        if account.usage_percent >= 100:
            should_expire = True
            reasons.append("使用额度已达100%")
        
        # 条件2：没有有效的订阅类型
        membership = (account.membership_type or "").lower()
        # 如果membership为空，或者不包含"trial"和"pro"，则认为无效
        # 有效类型：pro_trial, pro, free_trial
        # 无效类型：free, 空字符串, None
        if not membership or (membership == "free"):
            should_expire = True
            reasons.append("无有效订阅")
        elif "trial" not in membership and "pro" not in membership:
            # 如果既不是trial也不是pro，也认为无效
            should_expire = True
            reasons.append("订阅已过期")
        
        # 条件3：试用天数为0或负数（对于trial账号）
        if "trial" in membership and account.trial_days_left is not None and account.trial_days_left <= 0:
            should_expire = True
            reasons.append("试用期已结束")
        
        if should_expire:
            account.status = "expired"
            account.moved_to_expired_at = beijing_now()
            updated_count += 1
            reason_str = ", ".join(reasons)
            print(f"[自动失效] {account.email} - {reason_str}")
    
    if updated_count > 0:
        db.commit()
        print(f"[状态更新] 共有 {updated_count} 个账号被标记为已失效")
    
    return updated_count


@router.post("/import")
def import_accounts(
    data: AccountImport,
    db: Session = Depends(get_db),
    current_admin: Admin = Depends(get_current_admin)
):
    """导入账号（批量）"""
    accounts_info = crud.parse_account_text(data.accounts_text)
    
    if not accounts_info:
        raise HTTPException(status_code=400, detail="未找到有效的账号信息")
    
    imported = []
    failed = []
    
    for account_info in accounts_info:
        account = crud.create_account(db, account_info)
        if account:
            imported.append(account.email)
        else:
            failed.append(account_info.email)
    
    # 导入后自动检查账号状态
    check_and_update_expired_accounts(db)
    
    return {
        "success": True,
        "imported_count": len(imported),
        "failed_count": len(failed),
        "imported": imported,
        "failed": failed
    }


@router.get("/valid", response_model=List[AccountResponse])
def get_valid_accounts(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_admin: Admin = Depends(get_current_admin)
):
    """获取有效账号列表"""
    # 自动检查并更新已失效的账号
    check_and_update_expired_accounts(db)
    return crud.get_accounts_by_status(db, "valid", skip, limit)


@router.get("/in_use", response_model=List[AccountResponse])
def get_in_use_accounts(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_admin: Admin = Depends(get_current_admin)
):
    """获取使用中账号列表"""
    # 自动检查并更新已失效的账号
    check_and_update_expired_accounts(db)
    return crud.get_accounts_by_status(db, "in_use", skip, limit)


@router.get("/expired", response_model=List[AccountResponse])
def get_expired_accounts(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_admin: Admin = Depends(get_current_admin)
):
    """获取已失效账号列表"""
    return crud.get_accounts_by_status(db, "expired", skip, limit)


@router.get("/{account_id}", response_model=AccountResponse)
def get_account(
    account_id: int,
    db: Session = Depends(get_db),
    current_admin: Admin = Depends(get_current_admin)
):
    """获取单个账号"""
    account = crud.get_account_by_id(db, account_id)
    if not account:
        raise HTTPException(status_code=404, detail="账号不存在")
    return account


@router.put("/{account_id}", response_model=AccountResponse)
def update_account(
    account_id: int,
    account_update: AccountUpdate,
    db: Session = Depends(get_db),
    current_admin: Admin = Depends(get_current_admin)
):
    """更新账号"""
    account = crud.update_account(
        db,
        account_id,
        **account_update.model_dump(exclude_unset=True)
    )
    if not account:
        raise HTTPException(status_code=404, detail="账号不存在")
    return account


@router.post("/{account_id}/move/{new_status}", response_model=AccountResponse)
def move_account(
    account_id: int,
    new_status: str,
    db: Session = Depends(get_db),
    current_admin: Admin = Depends(get_current_admin)
):
    """移动账号到新状态"""
    if new_status not in ["valid", "in_use", "expired"]:
        raise HTTPException(status_code=400, detail="无效的状态")
    
    account = crud.move_account_to_status(db, account_id, new_status)
    if not account:
        raise HTTPException(status_code=404, detail="账号不存在")
    return account


@router.post("/{account_id}/refresh", response_model=AccountResponse)
def refresh_account_info(
    account_id: int,
    db: Session = Depends(get_db),
    current_admin: Admin = Depends(get_current_admin)
):
    """刷新账号信息（重新从 Cursor API 获取）"""
    account = crud.get_account_by_id(db, account_id)
    if not account:
        raise HTTPException(status_code=404, detail="账号不存在")
    
    # 重新获取账号信息
    from app.cursor_api_client import get_cursor_api_client
    api_client = get_cursor_api_client()
    
    account_data = api_client.get_account_info(
        account.access_token,
        account.session_token
    )
    
    if account_data:
        # 更新账号信息
        account.membership_type = account_data.get('membership_type', account.membership_type)
        account.usage_percent = account_data.get('usage_percent', account.usage_percent)
        account.trial_days_left = account_data.get('trial_days_left', account.trial_days_left)
        db.commit()
        db.refresh(account)
        
        # 刷新后检查是否需要标记为已失效
        check_and_update_expired_accounts(db)
        
        # 重新获取账号（状态可能已更新）
        db.refresh(account)
        return account
    else:
        raise HTTPException(status_code=500, detail="无法从 Cursor API 获取账号信息")


@router.delete("/{account_id}")
def delete_account(
    account_id: int,
    db: Session = Depends(get_db),
    current_admin: Admin = Depends(get_current_admin)
):
    """删除账号"""
    account = crud.get_account_by_id(db, account_id)
    if not account:
        raise HTTPException(status_code=404, detail="账号不存在")
    
    # 从数据库中删除
    db.delete(account)
    db.commit()
    
    return {"success": True, "message": f"账号 {account.email} 已删除"}


@router.get("/stats/summary", response_model=Stats)
def get_statistics(
    db: Session = Depends(get_db),
    current_admin: Admin = Depends(get_current_admin)
):
    """获取统计信息"""
    return crud.get_stats(db)


