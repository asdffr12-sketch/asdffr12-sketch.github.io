#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""定时任务调度器"""

from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from datetime import datetime
import logging
from sqlalchemy.orm import Session

from app.database import SessionLocal
from app.models import Account, SystemConfig
from app.cursor_api_client import get_cursor_api_client

logger = logging.getLogger(__name__)

# 创建后台调度器
scheduler = BackgroundScheduler(timezone='Asia/Shanghai')


def refresh_accounts_task():
    """定时刷新账号信息任务"""
    logger.info("=" * 60)
    logger.info(f"[定时任务] 开始刷新账号信息 - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    logger.info("=" * 60)
    
    db = SessionLocal()
    try:
        # 获取所有有效和使用中的账号
        accounts = db.query(Account).filter(
            Account.status.in_(["valid", "in_use"])
        ).all()
        
        if not accounts:
            logger.info("[定时任务] 没有需要刷新的账号")
            return
        
        logger.info(f"[定时任务] 找到 {len(accounts)} 个账号需要刷新")
        
        api_client = get_cursor_api_client()
        success_count = 0
        failed_count = 0
        
        for account in accounts:
            try:
                logger.info(f"[定时任务] 正在刷新: {account.email}")
                
                # 获取最新账号信息
                account_data = api_client.get_account_info(
                    account.access_token,
                    account.session_token
                )
                
                if account_data:
                    # 更新账号信息
                    account.membership_type = account_data.get('membership_type', account.membership_type)
                    account.usage_percent = account_data.get('usage_percent', account.usage_percent)
                    account.trial_days_left = account_data.get('trial_days_left', account.trial_days_left)
                    
                    logger.info(
                        f"[定时任务] ✓ {account.email} - "
                        f"{account.membership_type} - "
                        f"使用率: {account.usage_percent}% - "
                        f"剩余: {account.trial_days_left}天"
                    )
                    success_count += 1
                else:
                    logger.warning(f"[定时任务] ✗ 无法获取 {account.email} 的信息")
                    failed_count += 1
                    
            except Exception as e:
                logger.error(f"[定时任务] ✗ 刷新 {account.email} 失败: {e}")
                failed_count += 1
        
        # 提交所有更改
        db.commit()
        
        logger.info("=" * 60)
        logger.info(f"[定时任务] 刷新完成 - 成功: {success_count}, 失败: {failed_count}")
        logger.info("=" * 60)
        
    except Exception as e:
        logger.error(f"[定时任务] 任务执行失败: {e}", exc_info=True)
        db.rollback()
    finally:
        db.close()


def get_refresh_schedule(db: Session):
    """获取刷新时间配置"""
    try:
        config = db.query(SystemConfig).filter(
            SystemConfig.key == "refresh_schedule"
        ).first()
        
        if config:
            import json
            schedule_data = json.loads(config.value)
            return schedule_data.get("times", ["08:00", "20:00"])
        else:
            # 默认配置：早上8点和晚上20点
            return ["08:00", "20:00"]
    except Exception as e:
        logger.error(f"获取刷新时间配置失败: {e}")
        return ["08:00", "20:00"]


def update_schedule():
    """更新定时任务计划"""
    db = SessionLocal()
    try:
        # 获取配置的刷新时间
        refresh_times = get_refresh_schedule(db)
        
        # 移除所有现有的刷新任务
        for job in scheduler.get_jobs():
            if job.id.startswith('refresh_accounts_'):
                scheduler.remove_job(job.id)
        
        # 添加新的任务
        for time_str in refresh_times:
            try:
                hour, minute = map(int, time_str.split(':'))
                job_id = f'refresh_accounts_{time_str.replace(":", "")}'
                
                scheduler.add_job(
                    refresh_accounts_task,
                    CronTrigger(hour=hour, minute=minute, timezone='Asia/Shanghai'),
                    id=job_id,
                    name=f'刷新账号信息 - {time_str}',
                    replace_existing=True
                )
                
                logger.info(f"[调度器] 已添加定时任务: {time_str} (北京时间)")
            except Exception as e:
                logger.error(f"[调度器] 添加任务失败 {time_str}: {e}")
        
        # 打印所有任务
        logger.info("[调度器] 当前定时任务列表:")
        for job in scheduler.get_jobs():
            logger.info(f"  - {job.name} ({job.id})")
            
    except Exception as e:
        logger.error(f"[调度器] 更新计划失败: {e}", exc_info=True)
    finally:
        db.close()


def init_scheduler():
    """初始化调度器"""
    try:
        logger.info("[调度器] 正在初始化定时任务调度器...")
        
        # 更新任务计划
        update_schedule()
        
        # 启动调度器
        if not scheduler.running:
            scheduler.start()
            logger.info("[调度器] ✓ 调度器已启动")
        else:
            logger.info("[调度器] 调度器已在运行")
            
    except Exception as e:
        logger.error(f"[调度器] 初始化失败: {e}", exc_info=True)


def shutdown_scheduler():
    """关闭调度器"""
    try:
        if scheduler.running:
            scheduler.shutdown()
            logger.info("[调度器] 调度器已关闭")
    except Exception as e:
        logger.error(f"[调度器] 关闭失败: {e}")



