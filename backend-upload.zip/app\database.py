#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""数据库配置和初始化"""

from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import os

# 数据库 URL
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./youyu_cursor.db")

# 创建引擎
engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False} if "sqlite" in DATABASE_URL else {}
)

# 创建会话
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# 创建基类
Base = declarative_base()


def get_db():
    """获取数据库会话（依赖注入）"""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_db():
    """初始化数据库（创建所有表）"""
    from app.models import Admin, Account, APIKey
    Base.metadata.create_all(bind=engine)
    # 使用 ASCII 兼容的输出避免 Windows GBK 编码问题
    print("[OK] Database initialized successfully")


if __name__ == "__main__":
    init_db()


