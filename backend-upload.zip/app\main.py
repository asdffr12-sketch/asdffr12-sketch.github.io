#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""YouyuCursor 后端主应用"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
import os

from app.database import init_db
from app.routers import admin, accounts, keys, config, keys_v2, version
from app.scheduler import init_scheduler, shutdown_scheduler

# 创建FastAPI应用
app = FastAPI(
    title="YouyuCursor 管理系统",
    description="Cursor 账号管理后端 API",
    version="1.0.0"
)

# CORS配置
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 生产环境请改为具体域名
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 注册路由
app.include_router(admin.router)
app.include_router(accounts.router)
app.include_router(keys.router)
app.include_router(keys_v2.router)  # V2按需获取API
app.include_router(config.router)
app.include_router(version.router)  # 版本管理API

# 静态文件
frontend_dir = os.path.join(os.path.dirname(__file__), "..", "frontend")
if os.path.exists(frontend_dir):
    app.mount("/static", StaticFiles(directory=frontend_dir), name="static")


@app.on_event("startup")
async def startup_event():
    """启动时初始化数据库和调度器"""
    init_db()
    # 使用 ASCII 兼容的输出避免 Windows GBK 编码问题
    print("[OK] Database initialized")
    print("[INFO] API Docs: http://localhost:8000/docs")
    print("[INFO] Admin Panel: http://localhost:8000")
    
    # 初始化定时任务调度器
    init_scheduler()


@app.on_event("shutdown")
async def shutdown_event():
    """关闭时清理调度器"""
    shutdown_scheduler()


@app.get("/")
async def root():
    """首页 - 返回管理页面"""
    index_path = os.path.join(frontend_dir, "index.html")
    if os.path.exists(index_path):
        return FileResponse(index_path)
    return {"message": "YouyuCursor 管理系统 API", "docs": "/docs"}


@app.get("/health")
async def health_check():
    """健康检查"""
    return {"status": "ok", "service": "YouyuCursor Backend"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        reload=True
    )


