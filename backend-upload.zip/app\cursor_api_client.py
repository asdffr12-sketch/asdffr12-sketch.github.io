#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Cursor API 客户端封装（用于后端）"""

import json
import urllib.parse
from typing import Optional, Dict, Any
import logging

# 使用 requests 库（更现代、更易用）
try:
    import requests
    USE_REQUESTS = True
except ImportError:
    # 降级到 urllib
    import urllib.request
    import urllib.error
    USE_REQUESTS = False

logger = logging.getLogger(__name__)


class CursorAPIClient:
    """Cursor API 客户端（后端独立实现）"""
    
    BASE_URL = "https://cursor.com"
    
    def __init__(self, timeout: int = 30):
        self.timeout = timeout
        logger.info(f"使用 {'requests' if USE_REQUESTS else 'urllib'} 库进行HTTP请求")
    
    def _call_api(self, endpoint: str, token: str, use_cookie: bool = False) -> Optional[Dict[str, Any]]:
        """调用 Cursor API"""
        if USE_REQUESTS:
            return self._call_api_requests(endpoint, token, use_cookie)
        else:
            return self._call_api_urllib(endpoint, token, use_cookie)
    
    def _call_api_requests(self, endpoint: str, token: str, use_cookie: bool = False) -> Optional[Dict[str, Any]]:
        """使用 requests 库调用 API（推荐）"""
        try:
            url = f"{self.BASE_URL}{endpoint}"
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Accept': 'application/json',
            }
            
            if use_cookie:
                # Cookie 认证
                encoded_token = urllib.parse.quote(token, safe='') if '::' in token else token
                headers['Cookie'] = f'WorkosCursorSessionToken={encoded_token}'
                logger.debug(f"使用 Cookie 认证: {endpoint}")
            else:
                # Bearer 认证
                headers['Authorization'] = f'Bearer {token}'
                logger.debug(f"使用 Bearer 认证: {endpoint}")
            
            response = requests.get(url, headers=headers, timeout=self.timeout)
            
            if response.status_code == 200:
                data = response.json()
                logger.debug(f"✓ API 调用成功: {endpoint}")
                return data
            else:
                logger.warning(f"API 返回状态码: {response.status_code} - {endpoint}")
                logger.debug(f"响应内容: {response.text[:200]}")
                return None
                
        except requests.exceptions.Timeout:
            logger.error(f"❌ 请求超时: {endpoint}")
            return None
        except requests.exceptions.ConnectionError as e:
            logger.error(f"❌ 连接错误: {endpoint} - {str(e)}")
            return None
        except requests.exceptions.RequestException as e:
            logger.error(f"❌ 请求异常: {endpoint} - {type(e).__name__}: {str(e)}")
            return None
        except json.JSONDecodeError as e:
            logger.error(f"❌ JSON解析失败: {endpoint} - {str(e)}")
            return None
        except Exception as e:
            logger.error(f"❌ 未知异常: {endpoint} - {type(e).__name__}: {str(e)}", exc_info=True)
            return None
    
    def _call_api_urllib(self, endpoint: str, token: str, use_cookie: bool = False) -> Optional[Dict[str, Any]]:
        """使用 urllib 库调用 API（降级方案）"""
        try:
            url = f"{self.BASE_URL}{endpoint}"
            req = urllib.request.Request(url)
            
            if use_cookie:
                # Cookie 认证
                encoded_token = urllib.parse.quote(token, safe='') if '::' in token else token
                req.add_header('Cookie', f'WorkosCursorSessionToken={encoded_token}')
                logger.debug(f"使用 Cookie 认证: {endpoint}")
            else:
                # Bearer 认证
                req.add_header('Authorization', f'Bearer {token}')
                logger.debug(f"使用 Bearer 认证: {endpoint}")
            
            req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)')
            req.add_header('Accept', 'application/json')
            
            with urllib.request.urlopen(req, timeout=self.timeout) as response:
                if response.status == 200:
                    data = json.loads(response.read().decode('utf-8'))
                    logger.debug(f"✓ API 调用成功: {endpoint}")
                    return data
                else:
                    logger.warning(f"API 返回状态码: {response.status} - {endpoint}")
            return None
        except urllib.error.HTTPError as e:
            logger.error(f"❌ HTTP错误 {e.code}: {endpoint} - {e.reason}")
            return None
        except urllib.error.URLError as e:
            logger.error(f"❌ 网络错误: {endpoint} - {str(e.reason)}")
            return None
        except json.JSONDecodeError as e:
            logger.error(f"❌ JSON解析失败: {endpoint} - {str(e)}")
            return None
        except Exception as e:
            logger.error(f"❌ 未知异常: {endpoint} - {type(e).__name__}: {str(e)}", exc_info=True)
            return None
    
    def get_account_info(self, access_token: str, session_token: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """
        获取账号完整信息
        
        Args:
            access_token: AccessToken
            session_token: SessionToken（可选）
            
        Returns:
            Dict: 账号信息
        """
        try:
            # 选择使用哪个 Token
            use_cookie = False
            token = access_token
            
            if session_token and ('::' in session_token or '%3A%3A' in session_token):
                # 使用 SessionToken (Cookie 认证)
                use_cookie = True
                token = session_token
                logger.info("使用 SessionToken 获取账号信息")
            else:
                logger.info("使用 AccessToken 获取账号信息")
            
            # 获取用户信息
            user_info = self._call_api('/api/auth/me', token, use_cookie)
            if not user_info:
                logger.error("无法获取用户信息")
                return None
            
            # 获取使用情况
            usage_info = self._call_api('/api/usage-summary', token, use_cookie)
            
            # 获取订阅信息
            stripe_info = self._call_api('/api/auth/stripe', token, use_cookie)
            
            # 提取关键信息
            email = user_info.get('email', '')
            membership_type = 'free'
            usage_percent = 0.0
            trial_days_left = 0
            
            if usage_info:
                membership_type = usage_info.get('membershipType', 'free')
                individual_usage = usage_info.get('individualUsage', {})
                plan = individual_usage.get('plan', {})
                used = plan.get('used', 0)
                limit = plan.get('limit', 1000)
                usage_percent = round((used / limit) * 100, 1) if limit > 0 else 0
            
            if stripe_info:
                trial_days_left = stripe_info.get('daysRemainingOnTrial', 0)
                if 'membershipType' in stripe_info:
                    membership_type = stripe_info.get('membershipType', membership_type)
            
            result = {
                'email': email,
                'membership_type': membership_type,
                'usage_percent': usage_percent,
                'trial_days_left': trial_days_left,
                'subscription_status': self._format_subscription_status(membership_type, trial_days_left),
            }
            
            logger.info(f"✓ 获取账号信息成功: {email} - {result['subscription_status']}")
            return result
            
        except Exception as e:
            logger.error(f"获取账号信息失败: {e}")
            return None
    
    def _format_subscription_status(self, membership_type: str, days_left: int) -> str:
        """格式化订阅状态显示"""
        if 'trial' in membership_type.lower():
            return f"{days_left} days pro trial"
        elif membership_type.lower() == 'pro':
            return "Pro"
        elif membership_type.lower() == 'free':
            return "Free"
        else:
            return membership_type
    
    def validate_token(self, access_token: str, session_token: Optional[str] = None) -> bool:
        """
        验证 Token 是否有效
        
        Args:
            access_token: AccessToken
            session_token: SessionToken（可选）
            
        Returns:
            bool: Token 是否有效
        """
        try:
            # 尝试获取账号信息来验证
            info = self.get_account_info(access_token, session_token)
            return info is not None
        except Exception as e:
            logger.error(f"验证 Token 失败: {e}")
            return False


# 全局客户端实例
_client_instance = None


def get_cursor_api_client() -> CursorAPIClient:
    """获取全局 Cursor API 客户端实例"""
    global _client_instance
    if _client_instance is None:
        _client_instance = CursorAPIClient()
    return _client_instance

