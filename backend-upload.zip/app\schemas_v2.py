#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""API数据模型 - V2按需获取版本"""

from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime


class AccountInfo(BaseModel):
    """账号信息"""
    email: str
    access_token: str
    session_token: Optional[str] = None


class KeyGenerate(BaseModel):
    """生成密钥请求"""
    quota: int  # 配额数量（1或5）


class KeyResponse(BaseModel):
    """密钥响应（V2版本）"""
    id: int
    key: str
    quota: int
    used_count: int  # 已使用次数
    remaining_quota: int  # 剩余次数
    used: bool
    created_at: datetime
    first_used_at: Optional[datetime] = None
    used_at: Optional[datetime] = None
    
    class Config:
        from_attributes = True


class KeyValidate(BaseModel):
    """验证密钥请求"""
    key: str


class KeyValidateResponse(BaseModel):
    """密钥验证响应（V2版本 - 不返回账号）"""
    success: bool
    message: str
    quota: Optional[int] = None  # 总配额
    used_count: Optional[int] = None  # 已使用次数
    remaining_quota: Optional[int] = None  # 剩余次数


class AccountFetchRequest(BaseModel):
    """
    获取账号请求（V3.2.7：添加防重放字段）
    
    防重放机制：
    - request_id: 客户端生成的唯一请求ID（基于密钥+时间戳+随机数+哈希）
    - timestamp: 请求时间戳（秒）
    - signature: 请求签名（SHA256）
    """
    key: str
    request_id: str  # V3.2.7：防重放 - 唯一请求ID
    timestamp: int    # V3.2.7：防重放 - 时间戳（秒）
    signature: str    # V3.2.7：防重放 - 请求签名


class AccountFetchResponse(BaseModel):
    """获取账号响应"""
    success: bool
    message: str
    account: Optional[AccountInfo] = None
    remaining_quota: Optional[int] = None  # 获取后的剩余次数


