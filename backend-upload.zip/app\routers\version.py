#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
版本管理和更新检测 API
提供客户端版本检查、强制更新等功能
"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional
import os
from datetime import datetime

router = APIRouter(prefix="/api/version", tags=["version"])

# 版本配置
class VersionInfo(BaseModel):
    """版本信息"""
    version: str                    # 当前版本号
    min_version: str                # 最低支持版本
    force_update: bool              # 是否强制更新
    download_url: str               # 下载地址
    update_log: str                 # 更新日志
    release_date: str               # 发布日期
    file_size_mb: Optional[float]   # 文件大小（MB）
    file_md5: Optional[str]         # 文件MD5校验


class VersionCheckRequest(BaseModel):
    """版本检查请求"""
    client_version: str             # 客户端当前版本
    platform: str = "win32"         # 平台: win32, darwin, linux


class VersionCheckResponse(BaseModel):
    """版本检查响应"""
    need_update: bool               # 是否需要更新
    force_update: bool              # 是否强制更新
    latest_version: str             # 最新版本
    current_version: str            # 当前版本
    download_url: Optional[str]     # 下载地址
    update_log: Optional[str]       # 更新日志
    release_date: Optional[str]     # 发布日期
    message: str                    # 提示信息


# ==================== 版本配置 ====================
# 🔥 重要：每次发布新版本时更新这里

LATEST_VERSION = "3.2.9.4"          # 当前最新版本
MIN_SUPPORTED_VERSION = "3.2.0"     # 最低支持版本（低于此版本强制更新）
FORCE_UPDATE_ENABLED = True         # 是否启用强制更新

# 下载地址（根据实际情况配置）
# 可以是：
# 1. 服务器静态文件路径：http://YOUR_IP:8888/downloads/YouyuCursor_v3.2.9.4.exe
# 2. 云存储链接：https://xxx.oss.aliyuncs.com/YouyuCursor_v3.2.9.4.exe
# 3. GitHub Release：https://github.com/xxx/YouyuCursor/releases/download/v3.2.9.4/YouyuCursor.exe
DOWNLOAD_URL = "http://YOUR_SERVER_IP:8888/downloads/YouyuCursor_latest.exe"

# 更新日志
UPDATE_LOG = """
🎉 V3.2.9.4 更新内容

✨ 新增功能：
- 机器码生成优化，支持硬件绑定模式
- 添加设备指纹识别功能
- 优化账号切换逻辑

🐛 修复问题：
- 修复按钮交互动画bug
- 修复密钥验证问题

🎨 界面优化：
- 更换为🐟图标
- 优化按钮渐变动画
- 调整字体大小
"""

RELEASE_DATE = "2025-11-07"

# ==================================================


def compare_version(v1: str, v2: str) -> int:
    """
    比较版本号
    
    Args:
        v1: 版本号1
        v2: 版本号2
        
    Returns:
        1: v1 > v2
        0: v1 == v2
        -1: v1 < v2
    """
    try:
        # 移除可能的 'v' 前缀
        v1 = v1.lstrip('vV')
        v2 = v2.lstrip('vV')
        
        # 分割版本号
        parts1 = [int(x) for x in v1.split('.')]
        parts2 = [int(x) for x in v2.split('.')]
        
        # 补齐长度
        max_len = max(len(parts1), len(parts2))
        parts1.extend([0] * (max_len - len(parts1)))
        parts2.extend([0] * (max_len - len(parts2)))
        
        # 逐段比较
        for p1, p2 in zip(parts1, parts2):
            if p1 > p2:
                return 1
            elif p1 < p2:
                return -1
        
        return 0
    except Exception:
        # 解析失败，认为相等
        return 0


@router.post("/check", response_model=VersionCheckResponse)
async def check_version(request: VersionCheckRequest):
    """
    检查客户端版本
    
    客户端启动时调用此接口，判断是否需要更新
    
    逻辑：
    1. 如果客户端版本 < 最低支持版本 → 强制更新
    2. 如果客户端版本 < 最新版本 → 提示更新（可选是否强制）
    3. 如果客户端版本 = 最新版本 → 无需更新
    """
    client_ver = request.client_version
    
    # 比较版本
    cmp_latest = compare_version(client_ver, LATEST_VERSION)
    cmp_min = compare_version(client_ver, MIN_SUPPORTED_VERSION)
    
    # 低于最低支持版本 → 强制更新
    if cmp_min < 0:
        return VersionCheckResponse(
            need_update=True,
            force_update=True,
            latest_version=LATEST_VERSION,
            current_version=client_ver,
            download_url=DOWNLOAD_URL,
            update_log=UPDATE_LOG,
            release_date=RELEASE_DATE,
            message=f"您的版本过低（{client_ver}），必须更新到 {LATEST_VERSION} 才能继续使用"
        )
    
    # 低于最新版本 → 提示更新
    if cmp_latest < 0:
        return VersionCheckResponse(
            need_update=True,
            force_update=FORCE_UPDATE_ENABLED,
            latest_version=LATEST_VERSION,
            current_version=client_ver,
            download_url=DOWNLOAD_URL,
            update_log=UPDATE_LOG,
            release_date=RELEASE_DATE,
            message=f"发现新版本 {LATEST_VERSION}，建议更新以获得更好体验"
        )
    
    # 已是最新版本
    return VersionCheckResponse(
        need_update=False,
        force_update=False,
        latest_version=LATEST_VERSION,
        current_version=client_ver,
        download_url=None,
        update_log=None,
        release_date=RELEASE_DATE,
        message="当前已是最新版本"
    )


@router.get("/latest", response_model=VersionInfo)
async def get_latest_version():
    """
    获取最新版本信息
    
    返回服务器配置的最新版本信息
    """
    return VersionInfo(
        version=LATEST_VERSION,
        min_version=MIN_SUPPORTED_VERSION,
        force_update=FORCE_UPDATE_ENABLED,
        download_url=DOWNLOAD_URL,
        update_log=UPDATE_LOG,
        release_date=RELEASE_DATE,
        file_size_mb=None,
        file_md5=None
    )


@router.get("/update-log")
async def get_update_log():
    """
    获取更新日志
    
    返回纯文本格式的更新日志
    """
    return {
        "version": LATEST_VERSION,
        "release_date": RELEASE_DATE,
        "log": UPDATE_LOG
    }


@router.get("/config")
async def get_version_config():
    """
    获取版本配置（管理员用）
    
    返回当前的版本控制配置
    """
    return {
        "latest_version": LATEST_VERSION,
        "min_supported_version": MIN_SUPPORTED_VERSION,
        "force_update_enabled": FORCE_UPDATE_ENABLED,
        "download_url": DOWNLOAD_URL,
        "release_date": RELEASE_DATE
    }


# ==================== 使用示例 ====================
"""
客户端调用示例：

import httpx

async def check_for_updates(client_version: str):
    async with httpx.AsyncClient() as client:
        response = await client.post(
            "http://YOUR_SERVER_IP:8888/api/version/check",
            json={
                "client_version": client_version,
                "platform": "win32"
            }
        )
        return response.json()

# 使用
result = await check_for_updates("3.2.9")
if result["need_update"]:
    if result["force_update"]:
        print("必须更新！")
        print(f"下载地址：{result['download_url']}")
    else:
        print("发现新版本，建议更新")
"""







