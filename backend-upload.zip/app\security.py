#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
安全模块 - 防重放攻击
V3.2.7 新增
"""

import hashlib
import time
import secrets
import logging
from typing import Optional, Tuple
from datetime import datetime, timedelta
from sqlalchemy.orm import Session

from app.models import RequestLog

logger = logging.getLogger(__name__)


class RequestIdGenerator:
    """
    请求ID生成器
    基于密钥+时间戳+随机数+哈希的安全请求ID生成
    借鉴项目中的机器码生成方式
    """
    
    # 服务器密钥（应该从环境变量读取，这里用固定值示例）
    SERVER_SECRET = "youyu_cursor_server_secret_key_2025"
    
    @staticmethod
    def generate_request_id(key: str, timestamp: int) -> Tuple[str, str]:
        """
        生成请求ID和签名
        
        工作原理：
        1. 生成随机nonce（16字节）
        2. 计算签名：SHA256(key + timestamp + nonce + server_secret)
        3. 返回请求ID和签名
        
        Args:
            key: API密钥
            timestamp: 时间戳（秒）
            
        Returns:
            Tuple[request_id, signature]: (请求ID, 签名)
        """
        # 生成随机nonce（16字节 = 32位十六进制）
        nonce = secrets.token_hex(16)
        
        # 提取密钥前8位作为前缀（便于追溯）
        key_prefix = hashlib.sha256(key.encode()).hexdigest()[:8]
        
        # 构造请求ID: prefix_timestamp_nonce
        request_id = f"{key_prefix}_{timestamp}_{nonce}"
        
        # 生成签名：SHA256(key + timestamp + nonce + secret)
        sign_data = f"{key}|{timestamp}|{nonce}|{RequestIdGenerator.SERVER_SECRET}"
        signature = hashlib.sha256(sign_data.encode()).hexdigest()
        
        logger.debug(f"生成请求ID: {request_id[:20]}... (签名: {signature[:16]}...)")
        return request_id, signature
    
    @staticmethod
    def verify_request(
        key: str,
        request_id: str,
        timestamp: int,
        signature: str,
        max_age_seconds: int = 300
    ) -> Tuple[bool, Optional[str]]:
        """
        验证请求的合法性
        
        检查：
        1. 时间戳是否在有效期内（默认5分钟）
        2. 签名是否正确
        3. 请求ID格式是否正确
        
        Args:
            key: API密钥
            request_id: 请求ID
            timestamp: 时间戳
            signature: 签名
            max_age_seconds: 最大有效期（秒），默认300秒（5分钟）
            
        Returns:
            Tuple[is_valid, error_message]: (是否有效, 错误信息)
        """
        try:
            # 1. 检查时间戳（防止过期请求）
            current_time = int(time.time())
            time_diff = abs(current_time - timestamp)
            
            if time_diff > max_age_seconds:
                logger.warning(f"请求已过期: 时间差 {time_diff}秒（限制{max_age_seconds}秒）")
                return False, f"请求已过期（{time_diff}秒前）"
            
            # 2. 解析请求ID
            parts = request_id.split('_')
            if len(parts) != 3:
                logger.warning(f"请求ID格式错误: {request_id}")
                return False, "请求ID格式错误"
            
            key_prefix, req_timestamp, nonce = parts
            
            # 3. 验证时间戳一致性
            if int(req_timestamp) != timestamp:
                logger.warning(f"时间戳不匹配: {req_timestamp} vs {timestamp}")
                return False, "时间戳不匹配"
            
            # 4. 验证密钥前缀
            expected_prefix = hashlib.sha256(key.encode()).hexdigest()[:8]
            if key_prefix != expected_prefix:
                logger.warning(f"密钥前缀不匹配: {key_prefix} vs {expected_prefix}")
                return False, "密钥验证失败"
            
            # 5. 重新计算签名并验证
            sign_data = f"{key}|{timestamp}|{nonce}|{RequestIdGenerator.SERVER_SECRET}"
            expected_signature = hashlib.sha256(sign_data.encode()).hexdigest()
            
            if signature != expected_signature:
                logger.warning(f"签名验证失败: {signature[:16]}... vs {expected_signature[:16]}...")
                return False, "签名验证失败"
            
            logger.info(f"✓ 请求验证通过: {request_id[:20]}...")
            return True, None
            
        except Exception as e:
            logger.error(f"验证请求时异常: {e}")
            return False, f"验证异常: {str(e)}"


class AntiReplayService:
    """防重放服务"""
    
    @staticmethod
    def check_request_duplicate(
        db: Session,
        request_id: str,
        key: str
    ) -> Tuple[bool, Optional[str]]:
        """
        检查请求是否重复（防重放攻击）
        
        Args:
            db: 数据库会话
            request_id: 请求ID
            key: API密钥
            
        Returns:
            Tuple[is_valid, error_message]: (是否有效, 错误信息)
        """
        try:
            # 检查请求ID是否已存在
            existing = db.query(RequestLog)\
                .filter(RequestLog.request_id == request_id)\
                .first()
            
            if existing:
                logger.warning(f"检测到重放攻击: 请求ID已存在 {request_id}")
                logger.warning(f"  原始请求: {existing.created_at}")
                logger.warning(f"  密钥: {existing.key}")
                return False, "重复请求（疑似重放攻击）"
            
            # 记录请求
            log = RequestLog(
                request_id=request_id,
                key=key,
                timestamp=datetime.now()
            )
            db.add(log)
            db.flush()  # 立即写入（在事务内）
            
            logger.info(f"✓ 请求记录已保存: {request_id[:20]}...")
            return True, None
            
        except Exception as e:
            logger.error(f"检查请求重复时异常: {e}")
            return False, f"检查失败: {str(e)}"
    
    @staticmethod
    def cleanup_old_logs(db: Session, days: int = 7):
        """
        清理旧的请求日志（定期任务）
        
        Args:
            db: 数据库会话
            days: 保留天数，默认7天
        """
        try:
            cutoff_date = datetime.now() - timedelta(days=days)
            
            # 删除旧记录
            deleted = db.query(RequestLog)\
                .filter(RequestLog.created_at < cutoff_date)\
                .delete()
            
            db.commit()
            logger.info(f"✓ 清理旧请求日志: 删除 {deleted} 条（{days}天前）")
            
        except Exception as e:
            logger.error(f"清理请求日志失败: {e}")
            db.rollback()


def generate_request_id(key: str, timestamp: int) -> Tuple[str, str]:
    """
    便捷函数：生成请求ID和签名
    
    Args:
        key: API密钥
        timestamp: 时间戳
        
    Returns:
        Tuple[request_id, signature]: (请求ID, 签名)
    """
    return RequestIdGenerator.generate_request_id(key, timestamp)


def verify_request(
    key: str,
    request_id: str,
    timestamp: int,
    signature: str
) -> Tuple[bool, Optional[str]]:
    """
    便捷函数：验证请求
    
    Args:
        key: API密钥
        request_id: 请求ID
        timestamp: 时间戳
        signature: 签名
        
    Returns:
        Tuple[is_valid, error_message]: (是否有效, 错误信息)
    """
    return RequestIdGenerator.verify_request(key, request_id, timestamp, signature)

