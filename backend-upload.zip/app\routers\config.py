#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""系统配置路由"""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import List
import json

from app.database import get_db
from app.models import Admin, SystemConfig
from app.auth import get_current_admin
from app.scheduler import update_schedule, refresh_accounts_task

router = APIRouter(prefix="/api/config", tags=["系统配置"])


class RefreshScheduleConfig(BaseModel):
    """刷新计划配置"""
    times: List[str]  # 例如: ["08:00", "20:00"]


@router.get("/refresh-schedule")
def get_refresh_schedule(
    db: Session = Depends(get_db),
    current_admin: Admin = Depends(get_current_admin)
):
    """获取自动刷新时间配置"""
    config = db.query(SystemConfig).filter(
        SystemConfig.key == "refresh_schedule"
    ).first()
    
    if config:
        schedule_data = json.loads(config.value)
        return schedule_data
    else:
        # 返回默认配置
        return {
            "times": ["08:00", "20:00"],
            "description": "每天早上8点和晚上20点自动刷新账号信息"
        }


@router.post("/refresh-schedule")
def update_refresh_schedule(
    config_data: RefreshScheduleConfig,
    db: Session = Depends(get_db),
    current_admin: Admin = Depends(get_current_admin)
):
    """更新自动刷新时间配置"""
    
    # 验证时间格式
    for time_str in config_data.times:
        try:
            hour, minute = map(int, time_str.split(':'))
            if not (0 <= hour <= 23 and 0 <= minute <= 59):
                raise ValueError("时间超出范围")
        except:
            raise HTTPException(
                status_code=400,
                detail=f"无效的时间格式: {time_str}，应为 HH:MM 格式"
            )
    
    # 查找或创建配置
    config = db.query(SystemConfig).filter(
        SystemConfig.key == "refresh_schedule"
    ).first()
    
    config_value = {
        "times": config_data.times,
        "description": f"每天 {', '.join(config_data.times)} 自动刷新账号信息"
    }
    
    if config:
        config.value = json.dumps(config_value, ensure_ascii=False)
    else:
        config = SystemConfig(
            key="refresh_schedule",
            value=json.dumps(config_value, ensure_ascii=False),
            description="自动刷新账号信息的时间计划"
        )
        db.add(config)
    
    db.commit()
    
    # 更新调度器
    update_schedule()
    
    return {
        "success": True,
        "message": "刷新计划已更新",
        "config": config_value
    }


@router.post("/refresh-now")
def trigger_refresh_now(
    db: Session = Depends(get_db),
    current_admin: Admin = Depends(get_current_admin)
):
    """手动触发立即刷新"""
    try:
        # 在后台执行刷新任务
        import threading
        thread = threading.Thread(target=refresh_accounts_task)
        thread.daemon = True
        thread.start()
        
        return {
            "success": True,
            "message": "刷新任务已启动，请查看控制台日志"
        }
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"启动刷新任务失败: {str(e)}"
        )


@router.get("/scheduler-status")
def get_scheduler_status(
    current_admin: Admin = Depends(get_current_admin)
):
    """获取调度器状态"""
    from app.scheduler import scheduler
    
    jobs = []
    for job in scheduler.get_jobs():
        jobs.append({
            "id": job.id,
            "name": job.name,
            "next_run_time": job.next_run_time.strftime('%Y-%m-%d %H:%M:%S') if job.next_run_time else None
        })
    
    return {
        "running": scheduler.running,
        "jobs": jobs,
        "job_count": len(jobs)
    }



