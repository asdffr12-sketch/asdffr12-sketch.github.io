#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""数据库 CRUD 操作"""

import re
import uuid
from datetime import datetime, timezone, timedelta
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import List, Optional
import logging

from app.models import Account, APIKey
from app.schemas import AccountInfo
from app.cursor_api_client import get_cursor_api_client

logger = logging.getLogger(__name__)

# 北京时区（UTC+8）
BEIJING_TZ = timezone(timedelta(hours=8))


def parse_account_text(text: str) -> List[AccountInfo]:
    """解析账号文本，支持批量导入"""
    accounts = []
    
    # 正则表达式匹配账号信息
    pattern = r'【email[：:]([^】]+)】【accessToken[：:]([^】]+)】(?:【WorkosCursorSessionToken[：:]([^】]+)】)?'
    
    matches = re.finditer(pattern, text, re.MULTILINE | re.IGNORECASE)
    
    for match in matches:
        email = match.group(1).strip()
        access_token = match.group(2).strip()
        session_token = match.group(3).strip() if match.group(3) else None
        
        accounts.append(AccountInfo(
            email=email,
            access_token=access_token,
            session_token=session_token
        ))
    
    return accounts


def create_account(db: Session, account_info: AccountInfo) -> Optional[Account]:
    """创建账号并获取真实信息"""
    # 检查是否已存在
    existing = db.query(Account).filter(Account.email == account_info.email).first()
    if existing:
        logger.warning(f"账号 {account_info.email} 已存在，更新 Token")
        # 更新现有账号的 Token
        existing.access_token = account_info.access_token
        if account_info.session_token:
            existing.session_token = account_info.session_token
        db.commit()
        db.refresh(existing)
        return existing
    
    # 获取 Cursor API 客户端
    api_client = get_cursor_api_client()
    
    # 尝试获取账号真实信息（不阻塞导入流程）
    logger.info(f"正在获取账号信息: {account_info.email}")
    account_data = None
    
    try:
        account_data = api_client.get_account_info(
            account_info.access_token,
            account_info.session_token
        )
    except Exception as e:
        logger.error(f"获取账号信息时出错: {e}")
    
    # 使用获取到的信息或默认值
    if account_data:
        logger.info(f"✓ 账号信息获取成功: {account_data['email']} - {account_data['subscription_status']}")
        membership_type = account_data.get('membership_type', 'pro_trial')
        usage_percent = account_data.get('usage_percent', 0.0)
        trial_days_left = account_data.get('trial_days_left', 0)
        email = account_data.get('email', account_info.email)
    else:
        logger.warning(f"⚠️ 无法获取账号详细信息，使用默认值（账号仍会被导入）")
        # 使用合理的默认值
        membership_type = "pro_trial"
        usage_percent = 0.0
        trial_days_left = 14  # 假设14天试用
        email = account_info.email
    
    # 创建账号（无论是否获取到详细信息都创建）
    account = Account(
        email=email,
        access_token=account_info.access_token,
        session_token=account_info.session_token,
        status="valid",
        membership_type=membership_type,
        usage_percent=usage_percent,
        trial_days_left=trial_days_left
    )
    
    db.add(account)
    db.commit()
    db.refresh(account)
    
    logger.info(f"✓ 账号创建成功: {email}")
    return account


def get_accounts_by_status(db: Session, status: str, skip: int = 0, limit: int = 100) -> List[Account]:
    """
    按状态获取账号
    
    排序规则：按创建时间升序（最早的在前）
    """
    return db.query(Account).filter(Account.status == status)\
        .order_by(Account.created_at.asc())\
        .offset(skip)\
        .limit(limit)\
        .all()


def get_account_by_id(db: Session, account_id: int) -> Optional[Account]:
    """根据ID获取账号"""
    return db.query(Account).filter(Account.id == account_id).first()


def update_account(db: Session, account_id: int, **kwargs) -> Optional[Account]:
    """更新账号"""
    account = db.query(Account).filter(Account.id == account_id).first()
    if not account:
        return None
    
    for key, value in kwargs.items():
        if hasattr(account, key) and value is not None:
            setattr(account, key, value)
    
    db.commit()
    db.refresh(account)
    return account


def move_account_to_status(db: Session, account_id: int, new_status: str) -> Optional[Account]:
    """移动账号到新状态"""
    account = db.query(Account).filter(Account.id == account_id).first()
    if not account:
        return None
    
    account.status = new_status
    
    if new_status == "in_use":
        account.moved_to_in_use_at = datetime.now()
    elif new_status == "expired":
        account.moved_to_expired_at = datetime.now()
    
    db.commit()
    db.refresh(account)
    return account


def generate_api_key(db: Session, quota: int) -> APIKey:
    """生成API密钥"""
    key_string = f"YOUYU_{uuid.uuid4().hex[:16].upper()}"
    
    api_key = APIKey(
        key=key_string,
        quota=quota,
        used=False
    )
    
    db.add(api_key)
    db.commit()
    db.refresh(api_key)
    return api_key


def validate_and_use_key(db: Session, key: str) -> Optional[tuple[APIKey, List[Account]]]:
    """
    验证并使用密钥，返回密钥和账号列表
    
    优先级规则：
    - 按照账号创建时间升序排列（created_at ASC）
    - 优先分配创建时间最早的账号
    - 确保按导入顺序依次分配
    """
    api_key = db.query(APIKey).filter(APIKey.key == key).first()
    
    # 密钥不存在
    if not api_key:
        logger.warning(f"密钥不存在: {key}")
        return None
    
    # 密钥已使用
    if api_key.used:
        logger.warning(f"密钥已使用: {key}")
        return None
    
    # 获取有效账号（按创建时间升序排序，优先获取最早创建的账号）
    accounts = db.query(Account)\
        .filter(Account.status == "valid")\
        .order_by(Account.created_at.asc())\
        .limit(api_key.quota)\
        .all()
    
    # 账号数量不足
    if len(accounts) < api_key.quota:
        logger.warning(f"可用账号不足: 需要 {api_key.quota} 个，实际 {len(accounts)} 个")
        return None
    
    # 记录分配的账号信息
    account_emails = [acc.email for acc in accounts]
    logger.info(f"密钥 {key} 分配账号: {', '.join(account_emails)}")
    logger.info(f"分配的账号创建时间: {accounts[0].created_at} ~ {accounts[-1].created_at}")
    
    # 标记密钥为已使用
    api_key.used = True
    api_key.used_at = datetime.now()
    
    # 更新账号状态
    for account in accounts:
        account.status = "in_use"
        account.used_by_key = api_key.key
        account.moved_to_in_use_at = datetime.now()
        logger.info(f"账号 {account.email} 已分配给密钥 {key}")
    
    db.commit()
    
    logger.info(f"✓ 密钥 {key} 验证成功，分配 {len(accounts)} 个账号")
    return (api_key, accounts)


def get_stats(db: Session) -> dict:
    """获取统计信息"""
    return {
        "total_accounts": db.query(func.count(Account.id)).scalar(),
        "valid_accounts": db.query(func.count(Account.id)).filter(Account.status == "valid").scalar(),
        "in_use_accounts": db.query(func.count(Account.id)).filter(Account.status == "in_use").scalar(),
        "expired_accounts": db.query(func.count(Account.id)).filter(Account.status == "expired").scalar(),
        "total_keys": db.query(func.count(APIKey.id)).scalar(),
        "used_keys": db.query(func.count(APIKey.id)).filter(APIKey.used == True).scalar(),
    }


def get_all_keys(db: Session, skip: int = 0, limit: int = 100) -> List[APIKey]:
    """获取所有密钥"""
    return db.query(APIKey).order_by(APIKey.created_at.desc()).offset(skip).limit(limit).all()


