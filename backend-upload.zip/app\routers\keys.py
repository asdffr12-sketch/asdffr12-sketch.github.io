#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""密钥管理路由"""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from app.database import get_db
from app.schemas import (
    KeyGenerate, KeyResponse, KeyValidate, KeyValidateResponse, AccountInfo
)
from app.models import Admin
from app.auth import get_current_admin
from app import crud

router = APIRouter(prefix="/api/keys", tags=["密钥管理"])


@router.post("/generate", response_model=KeyResponse)
def generate_key(
    data: KeyGenerate,
    db: Session = Depends(get_db),
    current_admin: Admin = Depends(get_current_admin)
):
    """生成授权密钥"""
    if data.quota not in [1, 5]:
        raise HTTPException(status_code=400, detail="配额只能是1或5")
    
    api_key = crud.generate_api_key(db, data.quota)
    return api_key


@router.get("/list", response_model=List[KeyResponse])
def list_keys(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_admin: Admin = Depends(get_current_admin)
):
    """获取密钥列表"""
    return crud.get_all_keys(db, skip, limit)


@router.post("/validate", response_model=KeyValidateResponse)
def validate_key(data: KeyValidate, db: Session = Depends(get_db)):
    """验证并使用密钥（客户端API，无需认证）"""
    result = crud.validate_and_use_key(db, data.key)
    
    if not result:
        return KeyValidateResponse(
            success=False,
            message="密钥无效、已使用或可用账号数量不足",
            accounts=None
        )
    
    api_key, accounts = result
    
    # 转换为响应格式
    account_infos = [
        AccountInfo(
            email=account.email,
            access_token=account.access_token,
            session_token=account.session_token
        )
        for account in accounts
    ]
    
    return KeyValidateResponse(
        success=True,
        message=f"成功获取 {len(accounts)} 个账号",
        accounts=account_infos
    )


