#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""密钥管理路由 - V2按需获取版本（V3.2.7：添加防重放保护）"""

import logging
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.schemas_v2 import (
    KeyValidate, KeyValidateResponse, 
    AccountFetchRequest, AccountFetchResponse, AccountInfo
)
from app import crud_v2
from app.security import RequestIdGenerator, AntiReplayService

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v2/keys", tags=["密钥管理V2"])


@router.post("/validate", response_model=KeyValidateResponse)
def validate_key_v2(data: KeyValidate, db: Session = Depends(get_db)):
    """
    验证密钥（V2版本 - 仅验证，不分配账号）
    
    客户端流程：
    1. 用户输入密钥
    2. 调用此接口验证密钥
    3. 返回密钥状态和剩余次数
    4. 客户端保存密钥用于后续按需获取账号
    """
    api_key = crud_v2.validate_key_only(db, data.key)
    
    if not api_key:
        # 获取密钥状态用于详细错误信息
        status = crud_v2.get_key_status(db, data.key)
        if status and status["used_count"] >= status["quota"]:
            return KeyValidateResponse(
                success=False,
                message=f"密钥已用完（{status['used_count']}/{status['quota']}）"
            )
        return KeyValidateResponse(
            success=False,
            message="密钥无效或不存在"
        )
    
    return KeyValidateResponse(
        success=True,
        message=f"密钥验证成功，剩余 {api_key.remaining_quota} 次",
        quota=api_key.quota,
        used_count=api_key.used_count,
        remaining_quota=api_key.remaining_quota
    )


@router.post("/fetch-account", response_model=AccountFetchResponse)
def fetch_account(data: AccountFetchRequest, db: Session = Depends(get_db)):
    """
    使用密钥获取一个账号（按需获取）
    
    客户端流程：
    1. 用户点击"一键续杯"
    2. 使用保存的密钥调用此接口
    3. 获取一个账号信息
    4. 执行续杯流程
    5. 更新剩余次数显示
    
    安全保护：
    - 并发安全：使用数据库行锁保证并发安全
    - 防重放攻击：V3.2.7新增，验证请求ID和签名
    """
    logger.info(f"收到获取账号请求: request_id={data.request_id[:20]}...")
    
    # V3.2.7：防重放验证 - 验证签名和时间戳
    is_valid, error_msg = RequestIdGenerator.verify_request(
        data.key,
        data.request_id,
        data.timestamp,
        data.signature
    )
    
    if not is_valid:
        logger.warning(f"❌ 请求验证失败: {error_msg}")
        return AccountFetchResponse(
            success=False,
            message=f"请求验证失败: {error_msg}"
        )
    
    # V3.2.7：防重放验证 - 检查请求是否重复
    is_valid, error_msg = AntiReplayService.check_request_duplicate(
        db, data.request_id, data.key
    )
    
    if not is_valid:
        logger.warning(f"❌ 检测到重放攻击: {error_msg}")
        return AccountFetchResponse(
            success=False,
            message=f"{error_msg}"
        )
    
    # 检查可用账号数量
    available_count = crud_v2.get_available_accounts_count(db)
    if available_count == 0:
        return AccountFetchResponse(
            success=False,
            message="暂无可用账号"
        )
    
    # 获取账号
    result = crud_v2.fetch_one_account_with_key(db, data.key)
    
    if not result:
        # 获取密钥状态用于详细错误信息
        status = crud_v2.get_key_status(db, data.key)
        if not status:
            return AccountFetchResponse(
                success=False,
                message="密钥无效或不存在"
            )
        
        if status["used_count"] >= status["quota"]:
            return AccountFetchResponse(
                success=False,
                message=f"密钥已用完（{status['used_count']}/{status['quota']}）"
            )
        
        return AccountFetchResponse(
            success=False,
            message="获取账号失败，请重试"
        )
    
    account, remaining = result
    
    return AccountFetchResponse(
        success=True,
        message=f"成功获取账号，剩余 {remaining} 次",
        account=AccountInfo(
            email=account.email,
            access_token=account.access_token,
            session_token=account.session_token
        ),
        remaining_quota=remaining
    )


@router.get("/status/{key}")
def get_key_status(key: str, db: Session = Depends(get_db)):
    """
    获取密钥状态
    
    用于客户端实时查询剩余次数
    """
    status = crud_v2.get_key_status(db, key)
    
    if not status:
        raise HTTPException(status_code=404, detail="密钥不存在")
    
    return status


