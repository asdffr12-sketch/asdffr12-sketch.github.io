#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Pydantic 数据模型（请求/响应）"""

from pydantic import BaseModel, EmailStr
from datetime import datetime
from typing import Optional


# ============= 管理员相关 =============
class AdminLogin(BaseModel):
    username: str
    password: str


class Token(BaseModel):
    access_token: str
    token_type: str


# ============= 账号相关 =============
class AccountImport(BaseModel):
    """账号导入请求"""
    accounts_text: str  # 批量账号文本


class AccountInfo(BaseModel):
    """账号信息（单个）"""
    email: str
    access_token: str
    session_token: Optional[str] = None


class AccountResponse(BaseModel):
    """账号响应"""
    id: int
    email: str
    access_token: str
    session_token: Optional[str]
    membership_type: Optional[str]
    usage_percent: float
    trial_days_left: int
    status: str
    used_by_key: Optional[str]
    created_at: datetime
    updated_at: Optional[datetime]
    moved_to_in_use_at: Optional[datetime]
    moved_to_expired_at: Optional[datetime]
    
    class Config:
        from_attributes = True
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None
        }


class AccountUpdate(BaseModel):
    """账号更新请求"""
    usage_percent: Optional[float] = None
    trial_days_left: Optional[int] = None
    membership_type: Optional[str] = None
    status: Optional[str] = None


# ============= 密钥相关 =============
class KeyGenerate(BaseModel):
    """密钥生成请求"""
    quota: int  # 1 或 5


class KeyResponse(BaseModel):
    """密钥响应"""
    id: int
    key: str
    quota: int
    used: bool  # 兼容旧版本
    used_count: int = 0  # V3.1.0新增：使用次数
    remaining_quota: int = 0  # V3.1.0新增：剩余次数
    created_at: datetime
    used_at: Optional[datetime]
    first_used_at: Optional[datetime] = None  # V3.1.0新增：首次使用时间
    
    class Config:
        from_attributes = True


class KeyValidate(BaseModel):
    """密钥验证请求"""
    key: str


class KeyValidateResponse(BaseModel):
    """密钥验证响应"""
    success: bool
    message: str
    accounts: Optional[list[AccountInfo]] = None


# ============= 统计相关 =============
class Stats(BaseModel):
    """统计信息"""
    total_accounts: int
    valid_accounts: int
    in_use_accounts: int
    expired_accounts: int
    total_keys: int
    used_keys: int


